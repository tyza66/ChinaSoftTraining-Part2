package com.icss.test.mapper;

import com.icss.test.pojo.Role;

import java.util.List;

public interface RoleMapper {

    List<Role> selectRoles();
}
